import React from 'react';
import './procedurescard.css';
import "bootstrap/dist/css/bootstrap.min.css";

const ProceduresCard = props => {
    return(
        <div class="card">
        <img class="card-img-top" src={props.srcimg} alt="Card"></img>
            <div className="card-body">
                <h5 className="card-title">{props.title}</h5>
                <a href={props.link} className='btn btn-primary'>{props.textlink}</a>
            </div>
        </div>
    );
}
export default ProceduresCard; 
