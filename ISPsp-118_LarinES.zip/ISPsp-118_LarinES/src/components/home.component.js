import React, { Component } from "react";

import UserService from "../services/user.service";
import ProceduresCard from '../components/procedures-card.jsx';
import "./procedurescard.css";


import dentistry from "./img/dentistry.png"

export default class Home extends Component {
  constructor(props) {
    super(props);

    this.state = {
      content: ""
    };
  }

  componentDidMount() {
    UserService.getPublicContent().then(
      response => {
        this.setState({
          content: response.data
        });
      },
      error => {
        this.setState({
          content:
            (error.response && error.response.data) ||
            error.message ||
            error.toString()
        });
      }
    );
  }



  render() {


    return (
      <div class="container-fluid justify-content-center">
                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Услуги' textlink='Стоматологические услуги' />
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Импланты' textlink='Импланты'/>
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Лечение зубов' textlink='Лечение зубов'/>
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Зубные мосты' textlink='Зубные мосты'/>
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Коронки' textlink='Коронки'/>
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Отбеливание' textlink='Отбеливание'/>
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Винилы' textlink='Винилы'/>
                  </div>

                  <div className="col-md-4">
                      <ProceduresCard srcimg={dentistry} link='/home' title='Invisalign' textlink='Invisalign'/>
                  </div>
      </div>
    );
  }
}





/*
 return (
      <div className="container">
        <header className="jumbotron">
          <h3>{this.state.content}</h3>
        </header>
      </div>
    );
*/